<?php
/**
 * Plugin Name:       WP Komplett-Backup & Umzug
 * Description:       Sichert die komplette WordPress-Installation (Datenbank, wp-content, Kerndateien) in ein Archiv und spielt es auf demselben oder einem anderen Server wieder ein – inkl. automatischer Anpassung von URLs, Pfaden und Tabellen-Präfix.
 * Version:           1.0.0
 * Requires at least: 5.8
 * Requires PHP:      7.4
 * Author:            WP Komplett-Backup
 * License:           GPL-2.0-or-later
 * Text Domain:       wp-komplett-backup
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'WPKB_VERSION', '1.0.0' );
define( 'WPKB_FILE', __FILE__ );
define( 'WPKB_DIR', plugin_dir_path( __FILE__ ) );
define( 'WPKB_URL', plugin_dir_url( __FILE__ ) );
define( 'WPKB_SLUG', basename( __DIR__ ) );

if ( ! defined( 'WPKB_BACKUP_DIR' ) ) {
	// Kann in der wp-config.php überschrieben werden.
	define( 'WPKB_BACKUP_DIR', WP_CONTENT_DIR . '/wpkb-backups' );
}

require_once WPKB_DIR . 'includes/class-wpkb-tar.php';
require_once WPKB_DIR . 'includes/class-wpkb-replacer.php';
require_once WPKB_DIR . 'includes/class-wpkb-database.php';
require_once WPKB_DIR . 'includes/class-wpkb-job.php';
require_once WPKB_DIR . 'includes/class-wpkb-admin.php';

add_action( 'plugins_loaded', array( 'WPKB_Admin', 'init' ) );

if ( defined( 'WP_CLI' ) && WP_CLI ) {
	require_once WPKB_DIR . 'includes/class-wpkb-cli.php';
	WP_CLI::add_command( 'komplett-backup', 'WPKB_CLI' );
}

register_activation_hook( __FILE__, array( 'WPKB_Job', 'ensure_backup_dir' ) );
