<?php
/**
 * Dunkel Schlicht – Funktionen
 *
 * @package Dunkel_Schlicht
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'DUNKEL_VERSION', '1.3.0' );

/**
 * Theme-Unterstützung und Menüs registrieren.
 */
function dunkel_setup() {
	load_theme_textdomain( 'dunkel-schlicht', get_template_directory() . '/languages' );

	add_theme_support( 'title-tag' );
	add_theme_support( 'automatic-feed-links' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'responsive-embeds' );
	add_theme_support( 'align-wide' );
	add_theme_support(
		'html5',
		array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script', 'navigation-widgets' )
	);
	add_theme_support(
		'custom-logo',
		array(
			'height'      => 96,
			'width'       => 320,
			'flex-height' => true,
			'flex-width'  => true,
		)
	);

	register_nav_menus(
		array(
			'primary' => __( 'Hauptmenü (oben mittig)', 'dunkel-schlicht' ),
			'footer'  => __( 'Footer-Menü (Datenschutz & Impressum)', 'dunkel-schlicht' ),
		)
	);
}
add_action( 'after_setup_theme', 'dunkel_setup' );

/**
 * Inhaltsbreite für eingebettete Medien.
 */
function dunkel_content_width() {
	$GLOBALS['content_width'] = max( 480, (int) get_theme_mod( 'dunkel_content_width', 1000 ) - 48 );
}
add_action( 'after_setup_theme', 'dunkel_content_width', 0 );

/**
 * Styles und Skripte laden.
 */
function dunkel_scripts() {
	wp_enqueue_style( 'dunkel-style', get_stylesheet_uri(), array(), DUNKEL_VERSION );

	wp_enqueue_script(
		'dunkel-navigation',
		get_template_directory_uri() . '/assets/js/navigation.js',
		array(),
		DUNKEL_VERSION,
		array(
			'in_footer' => true,
			'strategy'  => 'defer',
		)
	);
	wp_add_inline_style( 'dunkel-style', dunkel_customizer_css() );

	wp_enqueue_script(
		'dunkel-mode',
		get_template_directory_uri() . '/assets/js/mode-toggle.js',
		array(),
		DUNKEL_VERSION,
		array(
			'in_footer' => true,
			'strategy'  => 'defer',
		)
	);
	wp_localize_script(
		'dunkel-mode',
		'dunkelMode',
		array(
			'fallback' => dunkel_default_mode(),
			'toLight'  => __( 'Zum hellen Design wechseln', 'dunkel-schlicht' ),
			'toDark'   => __( 'Zum dunklen Design wechseln', 'dunkel-schlicht' ),
		)
	);

	wp_localize_script(
		'dunkel-navigation',
		'dunkelNav',
		array(
			'expand'   => __( 'Untermenü öffnen', 'dunkel-schlicht' ),
			'collapse' => __( 'Untermenü schließen', 'dunkel-schlicht' ),
		)
	);

	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}
}
add_action( 'wp_enqueue_scripts', 'dunkel_scripts' );

/**
 * Fallback für das Footer-Menü: zeigt Datenschutz und Impressum,
 * solange im Backend noch kein Menü zugewiesen ist.
 */
function dunkel_footer_fallback() {
	$links = array();

	$privacy_id = (int) get_option( 'wp_page_for_privacy_policy' );
	if ( $privacy_id && 'publish' === get_post_status( $privacy_id ) ) {
		$links[] = '<li><a href="' . esc_url( get_permalink( $privacy_id ) ) . '">' . esc_html__( 'Datenschutz', 'dunkel-schlicht' ) . '</a></li>';
	}

	$imprint = get_page_by_path( 'impressum' );
	if ( $imprint && 'publish' === $imprint->post_status ) {
		$links[] = '<li><a href="' . esc_url( get_permalink( $imprint ) ) . '">' . esc_html__( 'Impressum', 'dunkel-schlicht' ) . '</a></li>';
	}

	if ( $links ) {
		echo '<ul class="menu">' . implode( '', $links ) . '</ul>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}
}

/**
 * Fallback für das Hauptmenü: einfache Seitenliste.
 */
function dunkel_primary_fallback() {
	echo '<ul class="menu">';
	wp_list_pages(
		array(
			'title_li' => '',
			'depth'    => 3,
		)
	);
	echo '</ul>';
}

/**
 * Seitenlisten-Klassen an Menü-Klassen angleichen (für den Fallback).
 */
function dunkel_page_css_class( $classes ) {
	if ( in_array( 'page_item_has_children', $classes, true ) ) {
		$classes[] = 'menu-item-has-children';
	}
	if ( in_array( 'current_page_item', $classes, true ) ) {
		$classes[] = 'current-menu-item';
	}
	if ( in_array( 'current_page_ancestor', $classes, true ) ) {
		$classes[] = 'current-menu-ancestor';
	}
	return $classes;
}
add_filter( 'page_css_class', 'dunkel_page_css_class' );

/**
 * Fallback-Untermenüs bekommen die Klasse .sub-menu.
 */
function dunkel_list_pages_submenu( $output ) {
	return str_replace( "<ul class='children'>", '<ul class="sub-menu">', $output );
}
add_filter( 'wp_list_pages', 'dunkel_list_pages_submenu' );

/**
 * Kürzerer Auszug.
 */
function dunkel_excerpt_length() {
	return 40;
}
add_filter( 'excerpt_length', 'dunkel_excerpt_length' );

function dunkel_excerpt_more() {
	return ' …';
}
add_filter( 'excerpt_more', 'dunkel_excerpt_more' );

/* =========================================================
 * Hell/Dunkel-Modus
 * ======================================================= */

/**
 * Standard-Design aus dem Customizer: auto | dark | light.
 */
function dunkel_default_mode() {
	$mode = get_theme_mod( 'dunkel_default_mode', 'auto' );
	return in_array( $mode, array( 'auto', 'dark', 'light' ), true ) ? $mode : 'auto';
}

/**
 * Setzt data-mode am <html>, bevor die Seite gezeichnet wird –
 * so blitzt beim Laden nie das falsche Design auf.
 */
function dunkel_mode_head_script() {
	$fallback = dunkel_default_mode();
	$toggle   = get_theme_mod( 'dunkel_show_toggle', true ) ? 'true' : 'false';
	?>
	<script>
	(function(){var d=document.documentElement,s=null,f=<?php echo wp_json_encode( $fallback ); ?>;
	if(<?php echo $toggle; // phpcs:ignore ?>){try{s=localStorage.getItem('dunkel-mode');}catch(e){}}
	var sys=window.matchMedia&&matchMedia('(prefers-color-scheme: light)').matches?'light':'dark';
	d.setAttribute('data-mode',(s==='light'||s==='dark')?s:(f==='auto'?sys:f));})();
	</script>
	<?php
}
add_action( 'wp_head', 'dunkel_mode_head_script', 0 );

/**
 * Hell/Dunkel-Umschalter ausgeben.
 */
function dunkel_mode_toggle() {
	if ( ! get_theme_mod( 'dunkel_show_toggle', true ) ) {
		return;
	}
	?>
	<button type="button" class="mode-toggle" aria-label="<?php esc_attr_e( 'Design wechseln', 'dunkel-schlicht' ); ?>">
		<svg class="icon-sun" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" aria-hidden="true"><circle cx="12" cy="12" r="4.2"/><path d="M12 2.5v2.2M12 19.3v2.2M4.6 4.6l1.6 1.6M17.8 17.8l1.6 1.6M2.5 12h2.2M19.3 12h2.2M4.6 19.4l1.6-1.6M17.8 6.2l1.6-1.6"/></svg>
		<svg class="icon-moon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round" aria-hidden="true"><path d="M20 14.6A8.2 8.2 0 0 1 9.4 4a8.2 8.2 0 1 0 10.6 10.6Z"/></svg>
	</button>
	<?php
}

/* =========================================================
 * Customizer
 * ======================================================= */

/**
 * Zahl auf einen Bereich begrenzen.
 */
function dunkel_sanitize_range( $value, $setting ) {
	$attrs = $setting->manager->get_control( $setting->id )->input_attrs;
	$value = absint( $value );
	return max( $attrs['min'], min( $attrs['max'], $value ) );
}

function dunkel_sanitize_mode( $value ) {
	return in_array( $value, array( 'auto', 'dark', 'light' ), true ) ? $value : 'auto';
}

/**
 * Optionen unter Design → Customizer → „Theme-Optionen“.
 */
function dunkel_customize_register( $wp_customize ) {
	$wp_customize->add_section(
		'dunkel_options',
		array(
			'title'    => __( 'Theme-Optionen', 'dunkel-schlicht' ),
			'priority' => 30,
		)
	);

	// Logogröße.
	$wp_customize->add_setting(
		'dunkel_logo_height',
		array(
			'default'           => 80,
			'sanitize_callback' => 'dunkel_sanitize_range',
		)
	);
	$wp_customize->add_control(
		'dunkel_logo_height',
		array(
			'label'       => __( 'Logohöhe (px)', 'dunkel-schlicht' ),
			'description' => __( 'Die Kopfzeile passt sich automatisch an. Auf dem Handy wird das Logo höchstens 50 px hoch.', 'dunkel-schlicht' ),
			'section'     => 'dunkel_options',
			'type'        => 'range',
			'input_attrs' => array(
				'min'  => 30,
				'max'  => 160,
				'step' => 2,
			),
		)
	);

	// Inhaltsbreite.
	$wp_customize->add_setting(
		'dunkel_content_width',
		array(
			'default'           => 1000,
			'sanitize_callback' => 'dunkel_sanitize_range',
		)
	);
	$wp_customize->add_control(
		'dunkel_content_width',
		array(
			'label'       => __( 'Inhaltsbreite (px)', 'dunkel-schlicht' ),
			'description' => __( 'Maximale Breite des Inhaltsbereichs.', 'dunkel-schlicht' ),
			'section'     => 'dunkel_options',
			'type'        => 'range',
			'input_attrs' => array(
				'min'  => 600,
				'max'  => 1400,
				'step' => 20,
			),
		)
	);

	// Standard-Design.
	$wp_customize->add_setting(
		'dunkel_default_mode',
		array(
			'default'           => 'auto',
			'sanitize_callback' => 'dunkel_sanitize_mode',
		)
	);
	$wp_customize->add_control(
		'dunkel_default_mode',
		array(
			'label'   => __( 'Standard-Design', 'dunkel-schlicht' ),
			'section' => 'dunkel_options',
			'type'    => 'radio',
			'choices' => array(
				'auto'  => __( 'Automatisch (nach Geräteeinstellung)', 'dunkel-schlicht' ),
				'dark'  => __( 'Immer dunkel', 'dunkel-schlicht' ),
				'light' => __( 'Immer hell', 'dunkel-schlicht' ),
			),
		)
	);

	// Umschalter anzeigen.
	$wp_customize->add_setting(
		'dunkel_show_toggle',
		array(
			'default'           => true,
			'sanitize_callback' => 'rest_sanitize_boolean',
		)
	);
	$wp_customize->add_control(
		'dunkel_show_toggle',
		array(
			'label'       => __( 'Hell/Dunkel-Umschalter im Header anzeigen', 'dunkel-schlicht' ),
			'description' => __( 'Besucher können das Design selbst wählen; die Wahl wird im Browser gespeichert.', 'dunkel-schlicht' ),
			'section'     => 'dunkel_options',
			'type'        => 'checkbox',
		)
	);

	// Logo für das helle Design.
	$wp_customize->add_setting(
		'dunkel_logo_light',
		array(
			'default'           => 0,
			'sanitize_callback' => 'absint',
		)
	);
	$wp_customize->add_control(
		new WP_Customize_Media_Control(
			$wp_customize,
			'dunkel_logo_light',
			array(
				'label'       => __( 'Logo für das helle Design (optional)', 'dunkel-schlicht' ),
				'description' => __( 'Wird statt des normalen Logos gezeigt, wenn das helle Design aktiv ist.', 'dunkel-schlicht' ),
				'section'     => 'dunkel_options',
				'mime_type'   => 'image',
			)
		)
	);
}
add_action( 'customize_register', 'dunkel_customize_register' );

/**
 * CSS-Variablen aus den Customizer-Werten.
 */
function dunkel_customizer_css() {
	$logo  = max( 30, min( 160, (int) get_theme_mod( 'dunkel_logo_height', 80 ) ) );
	$width = max( 600, min( 1400, (int) get_theme_mod( 'dunkel_content_width', 1000 ) ) );
	return sprintf( ':root{--logo-h:%dpx;--content-w:%dpx;}', $logo, $width );
}

/**
 * Zahlenwert neben den Schiebereglern im Customizer anzeigen.
 */
function dunkel_customizer_range_values() {
	?>
	<script>
	(function(api){
		['dunkel_logo_height','dunkel_content_width'].forEach(function(id){
			api.control(id,function(control){
				control.deferred.embedded.done(function(){
					var r=control.container.find('input[type="range"]')[0];
					if(!r){return;}
					var o=document.createElement('output');
					o.style.cssText='display:inline-block;min-width:4em;margin-left:8px;font-weight:600;';
					o.textContent=r.value+' px';
					r.insertAdjacentElement('afterend',o);
					r.addEventListener('input',function(){o.textContent=r.value+' px';});
				});
			});
		});
	})(wp.customize);
	</script>
	<?php
}
add_action( 'customize_controls_print_footer_scripts', 'dunkel_customizer_range_values' );
