<?php
/**
 * Shortcodes:
 *   [webcam_archiv]                         Kalender aller Kameras (mit Umschalter, falls mehrere)
 *   [webcam_archiv kamera="cam2"]           nur eine bestimmte Kamera
 *   [webcam_archiv kamera="cam1,cam3"]      Auswahl mehrerer Kameras
 *   [webcam_archiv datum="2026-11-09" tempo="6"]
 *   [webcam_aktuell kamera="cam2" refresh="60" archiv="/webcam-archiv/"]
 */

defined( 'ABSPATH' ) || exit;

final class WCA_Frontend {

	public static function init() {
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'register_assets' ) );
		add_shortcode( 'webcam_archiv', array( __CLASS__, 'shortcode_archive' ) );
		add_shortcode( 'webcam_aktuell', array( __CLASS__, 'shortcode_latest' ) );
	}

	public static function register_assets() {
		wp_register_style( 'wca-frontend', WCA_URL . 'assets/css/frontend.css', array(), WCA_VERSION );
		wp_register_script( 'wca-frontend', WCA_URL . 'assets/js/frontend.js', array(), WCA_VERSION, true );
	}

	private static function enqueue() {
		if ( ! wp_script_is( 'wca-frontend', 'registered' ) ) {
			self::register_assets();
		}
		wp_enqueue_style( 'wca-frontend' );
		wp_enqueue_script( 'wca-frontend' );
	}

	/**
	 * Kameras aus dem Shortcode-Attribut "kamera" auflösen (ID, Name oder Liste).
	 */
	private static function resolve_cameras( $attr ) {
		$all = WCA_Plugin::cameras();
		$attr = trim( (string) $attr );
		if ( '' === $attr || 'alle' === $attr ) {
			return $all;
		}
		$out = array();
		foreach ( array_map( 'trim', explode( ',', $attr ) ) as $want ) {
			foreach ( $all as $id => $c ) {
				if ( $want === $id || 0 === strcasecmp( $want, $c['name'] ) ) {
					$out[ $id ] = $c;
				}
			}
		}
		return $out;
	}

	private static function base_config() {
		$o = WCA_Plugin::options();
		return array(
			'rest'      => esc_url_raw( rest_url( WCA_REST::NS . '/' ) ),
			'nonce'     => $o['require_login'] ? wp_create_nonce( 'wp_rest' ) : '',
			'locale'    => str_replace( '_', '-', get_locale() ),
			'weekStart' => (int) $o['week_start'],
			'i18n'      => array(
				'latest'   => 'Neuestes Bild',
				'image'    => 'Bild',
				'images'   => 'Bilder',
				'original' => 'Originalgröße',
				'play'     => 'Zeitraffer abspielen',
				'pause'    => 'Zeitraffer anhalten',
				'prev'     => 'Vorheriges Bild',
				'next'     => 'Nächstes Bild',
				'prevMon'  => 'Vorheriger Monat',
				'nextMon'  => 'Nächster Monat',
				'prevDay'  => 'Vorheriger Tag',
				'nextDay'  => 'Nächster Tag',
				'camera'   => 'Kamera',
				'clock'    => 'Uhr',
				'empty'    => 'Von dieser Kamera sind noch keine Bilder vorhanden.',
				'noImages' => 'Für diesen Tag sind keine Bilder vorhanden.',
				'error'    => 'Die Bilder konnten nicht geladen werden.',
				'login'    => 'Bitte melde dich an, um das Archiv zu sehen.',
			),
		);
	}

	public static function shortcode_archive( $atts ) {
		$atts = shortcode_atts(
			array(
				'kamera' => '',
				'datum'  => '',
				'tempo'  => 4, // Bilder pro Sekunde im Zeitraffer
			),
			$atts,
			'webcam_archiv'
		);

		if ( WCA_Plugin::options()['require_login'] && ! is_user_logged_in() ) {
			return '<p class="wca-message">Bitte melde dich an, um das Webcam-Archiv zu sehen.</p>';
		}

		$cams = self::resolve_cameras( $atts['kamera'] );
		if ( ! $cams ) {
			return current_user_can( 'manage_options' )
				? '<p class="wca-message">Webcam Archiv: Kamera „' . esc_html( $atts['kamera'] ) . '“ nicht gefunden.</p>'
				: '';
		}

		self::enqueue();

		$cfg            = self::base_config();
		$cfg['cameras'] = array();
		foreach ( $cams as $id => $c ) {
			$cfg['cameras'][] = array(
				'id'   => $id,
				'name' => $c['name'],
			);
		}
		$cfg['initialDate'] = preg_match( '/^\d{4}-\d{2}-\d{2}$/', $atts['datum'] ) ? $atts['datum'] : '';
		$cfg['fps']         = max( 1, min( 25, (int) $atts['tempo'] ) );

		return sprintf(
			'<div class="wca-archive" data-wca="%s"><noscript>Für das Webcam-Archiv wird JavaScript benötigt.</noscript></div>',
			esc_attr( wp_json_encode( $cfg ) )
		);
	}

	public static function shortcode_latest( $atts ) {
		$atts = shortcode_atts(
			array(
				'kamera'  => '',
				'refresh' => 60,
				'archiv'  => '',
			),
			$atts,
			'webcam_aktuell'
		);

		if ( WCA_Plugin::options()['require_login'] && ! is_user_logged_in() ) {
			return '';
		}

		$cams = self::resolve_cameras( '' === $atts['kamera'] ? WCA_Plugin::default_camera_id() : $atts['kamera'] );
		if ( ! $cams ) {
			return '';
		}
		reset( $cams );
		$cam_id = key( $cams );
		$cam    = current( $cams );

		self::enqueue();

		$img = WCA_Archiver::latest( $cam_id );
		$cfg = self::base_config();
		unset( $cfg['i18n'] );
		$cfg['refresh'] = max( 0, (int) $atts['refresh'] );
		$cfg['camera']  = $cam_id;

		if ( ! $img ) {
			return '<div class="wca-latest"><p class="wca-message">Noch kein Bild von ' . esc_html( $cam['name'] ) . ' vorhanden.</p></div>';
		}

		$ts   = strtotime( $img['date'] . ' ' . $img['time'] );
		$when = date_i18n( get_option( 'date_format' ) . ', H:i', $ts ) . ' Uhr';

		$html  = sprintf( '<figure class="wca-latest" data-wca="%s">', esc_attr( wp_json_encode( $cfg ) ) );
		$inner = sprintf(
			'<img src="%s" width="%d" height="%d" alt="%s">',
			esc_url( $img['full'] ),
			(int) $img['w'],
			(int) $img['h'],
			esc_attr( $cam['name'] . ' – ' . $when )
		);
		if ( $atts['archiv'] ) {
			$link  = $atts['archiv'] . ( false === strpos( $atts['archiv'], '#' ) ? '#wca=' . $img['date'] . '&kamera=' . $cam_id : '' );
			$inner = sprintf( '<a href="%s">%s</a>', esc_url( $link ), $inner );
		}
		$html .= $inner;
		$html .= sprintf( '<figcaption class="wca-latest-time">%s</figcaption></figure>', esc_html( $when ) );
		return $html;
	}
}
