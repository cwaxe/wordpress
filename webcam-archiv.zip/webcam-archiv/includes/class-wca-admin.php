<?php
/**
 * Einstellungsseite unter "Einstellungen → Webcam Archiv".
 */

defined( 'ABSPATH' ) || exit;

final class WCA_Admin {

	const SLUG = 'webcam-archiv';

	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ) );
		add_action( 'admin_init', array( __CLASS__, 'register' ) );
		add_action( 'admin_init', array( 'WCA_Plugin', 'ensure_scheduled' ) );
		add_action( 'admin_post_wca_action', array( __CLASS__, 'handle_action' ) );
		add_filter( 'plugin_action_links_' . plugin_basename( WCA_FILE ), array( __CLASS__, 'action_links' ) );
	}

	public static function action_links( $links ) {
		array_unshift( $links, '<a href="' . esc_url( admin_url( 'options-general.php?page=' . self::SLUG ) ) . '">Einstellungen</a>' );
		return $links;
	}

	public static function menu() {
		add_options_page( 'Webcam Archiv', 'Webcam Archiv', 'manage_options', self::SLUG, array( __CLASS__, 'page' ) );
	}

	public static function register() {
		register_setting(
			'wca_settings',
			WCA_Plugin::OPTION,
			array(
				'type'              => 'array',
				'sanitize_callback' => array( __CLASS__, 'sanitize' ),
			)
		);
	}

	/* ---------------------------------------------------------------------
	 * Speichern
	 * ------------------------------------------------------------------ */

	private static function clamp( $v, $min, $max, $def ) {
		$v = is_numeric( $v ) ? (int) $v : $def;
		return max( $min, min( $max, $v ) );
	}

	private static function time_val( $v, $def ) {
		return ( is_string( $v ) && preg_match( '/^([01]\d|2[0-3]):[0-5]\d$/', $v ) ) ? $v : $def;
	}

	public static function sanitize( $in ) {
		$in  = is_array( $in ) ? $in : array();
		$old = WCA_Plugin::options();
		$o   = array();

		// Kameras.
		$taken = array_fill_keys( array_merge( array_keys( $old['cameras'] ), WCA_Archiver::camera_ids_in_db() ), true );
		$used  = array();
		$cams  = array();
		$n     = 0;

		foreach ( (array) ( $in['cameras'] ?? array() ) as $c ) {
			if ( ! is_array( $c ) ) {
				continue;
			}
			$id = sanitize_key( $c['id'] ?? '' );

			if ( ! empty( $c['remove'] ) ) {
				if ( '' !== $id && ! empty( $c['remove_images'] ) ) {
					$del = WCA_Archiver::delete_camera_images( $id );
					WCA_Plugin::log( 'info', sprintf( 'Kamera „%s“ entfernt, %d Bilder gelöscht.', sanitize_text_field( $c['name'] ?? $id ), $del ) );
				}
				continue;
			}

			++$n;
			if ( '' === $id || isset( $used[ $id ] ) ) {
				$i = 1;
				while ( isset( $taken[ 'cam' . $i ] ) || isset( $used[ 'cam' . $i ] ) ) {
					++$i;
				}
				$id = 'cam' . $i;
			}
			$used[ $id ] = true;

			$name = trim( sanitize_text_field( $c['name'] ?? '' ) );
			$mode = $c['source_mode'] ?? 'url';

			$cams[] = array(
				'id'                  => $id,
				'name'                => '' !== $name ? $name : 'Webcam ' . $n,
				'source_mode'         => in_array( $mode, array( 'url', 'folder', 'both' ), true ) ? $mode : 'url',
				'source_url'          => esc_url_raw( trim( (string) ( $c['source_url'] ?? '' ) ) ),
				'http_user'           => sanitize_text_field( $c['http_user'] ?? '' ),
				'http_pass'           => (string) ( $c['http_pass'] ?? '' ),
				'timeout'             => self::clamp( $c['timeout'] ?? 20, 5, 120, 20 ),
				'interval'            => self::clamp( $c['interval'] ?? 15, 1, 1440, 15 ),
				'time_from'           => self::time_val( $c['time_from'] ?? '', '00:00' ),
				'time_to'             => self::time_val( $c['time_to'] ?? '', '23:59' ),
				'skip_duplicates'     => empty( $c['skip_duplicates'] ) ? 0 : 1,
				'import_dir'          => untrailingslashit( wp_normalize_path( sanitize_text_field( $c['import_dir'] ?? '' ) ) ),
				'delete_after_import' => empty( $c['delete_after_import'] ) ? 0 : 1,
				'max_width'           => self::clamp( $c['max_width'] ?? 0, 0, 10000, 0 ),
			);
		}
		if ( ! $cams ) {
			add_settings_error( WCA_Plugin::OPTION, 'wca_nocam', 'Mindestens eine Kamera muss bestehen bleiben.' );
			$cams = array_values( $old['cameras'] );
		}
		$o['cameras'] = $cams;

		// Allgemein.
		$o['jpeg_quality']   = self::clamp( $in['jpeg_quality'] ?? 85, 30, 100, 85 );
		$o['thumb_width']    = self::clamp( $in['thumb_width'] ?? 320, 80, 1000, 320 );
		$o['retention_days'] = self::clamp( $in['retention_days'] ?? 0, 0, 36500, 0 );
		$o['require_login']  = empty( $in['require_login'] ) ? 0 : 1;
		$o['week_start']     = empty( $in['week_start'] ) ? 0 : 1;
		$o['trigger_key']    = ( ! empty( $in['regen_key'] ) || empty( $old['trigger_key'] ) ) ? wp_generate_password( 32, false ) : $old['trigger_key'];

		return $o;
	}

	/* ---------------------------------------------------------------------
	 * Manuelle Aktionen
	 * ------------------------------------------------------------------ */

	public static function handle_action() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Keine Berechtigung.' );
		}
		check_admin_referer( 'wca_action' );

		$do  = sanitize_key( $_POST['do'] ?? '' );
		$cam = WCA_Plugin::camera( sanitize_key( $_POST['cam'] ?? '' ) );
		$msg = '';

		switch ( $do ) {
			case 'capture':
				if ( $cam ) {
					$r   = WCA_Archiver::capture_from_url( $cam );
					$msg = $cam['name'] . ': ' . ( is_wp_error( $r ) ? 'Fehler: ' . $r->get_error_message() : 'Abruf ' . $r );
				}
				break;
			case 'import':
				if ( $cam ) {
					$r   = WCA_Archiver::import_folder( $cam );
					$msg = $cam['name'] . ': ' . ( is_wp_error( $r ) ? 'Fehler: ' . $r->get_error_message() : 'Import ' . $r );
				}
				break;
			case 'cleanup':
				$msg = sprintf( 'Bereinigung: %d Bilder gelöscht.', WCA_Archiver::cleanup() );
				break;
			case 'delete_day':
				$date = sanitize_text_field( wp_unslash( $_POST['date'] ?? '' ) );
				if ( $cam && preg_match( '/^\d{4}-\d{2}-\d{2}$/', $date ) ) {
					$msg = sprintf( '%s: %d Bilder vom %s gelöscht.', $cam['name'], WCA_Archiver::delete_day( $date, $cam['id'] ), $date );
				} else {
					$msg = 'Fehler: Ungültige Kamera oder ungültiges Datum.';
				}
				break;
			case 'clear_log':
				delete_option( 'wca_log' );
				$msg = 'Protokoll geleert.';
				break;
		}

		set_transient( 'wca_notice_' . get_current_user_id(), $msg, 60 );
		wp_safe_redirect( admin_url( 'options-general.php?page=' . self::SLUG ) );
		exit;
	}

	private static function action_button( $do, $label, $cam_id = '', $class = 'button', $extra = '' ) {
		?>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:inline-block;margin:0 6px 6px 0">
			<?php wp_nonce_field( 'wca_action' ); ?>
			<input type="hidden" name="action" value="wca_action">
			<input type="hidden" name="do" value="<?php echo esc_attr( $do ); ?>">
			<?php if ( $cam_id ) : ?>
				<input type="hidden" name="cam" value="<?php echo esc_attr( $cam_id ); ?>">
			<?php endif; ?>
			<?php echo $extra; // phpcs:ignore WordPress.Security.EscapeOutput ?>
			<button type="submit" class="<?php echo esc_attr( $class ); ?>"><?php echo esc_html( $label ); ?></button>
		</form>
		<?php
	}

	/* ---------------------------------------------------------------------
	 * Kamera-Block im Formular
	 * ------------------------------------------------------------------ */

	private static function camera_fields( $idx, array $c ) {
		$f    = WCA_Plugin::OPTION . '[cameras][' . $idx . ']';
		$uid  = 'wca-' . $idx;
		$isnew = '' === $c['id'];
		?>
		<div class="wca-camera postbox" style="padding:0 16px 8px;margin:16px 0">
			<input type="hidden" name="<?php echo esc_attr( $f ); ?>[id]" value="<?php echo esc_attr( $c['id'] ); ?>">
			<h3 style="display:flex;gap:10px;align-items:center;margin:14px 0 4px">
				<span class="dashicons dashicons-video-alt2"></span>
				<input type="text" name="<?php echo esc_attr( $f ); ?>[name]" value="<?php echo esc_attr( $c['name'] ); ?>" placeholder="Name der Kamera" style="font-size:16px;font-weight:600;min-width:240px">
				<?php if ( ! $isnew ) : ?>
					<code title="Kürzel für Shortcodes">kamera="<?php echo esc_html( $c['id'] ); ?>"</code>
				<?php else : ?>
					<em style="font-weight:normal;color:#646970">neu – Kürzel wird beim Speichern vergeben</em>
				<?php endif; ?>
			</h3>
			<table class="form-table" role="presentation">
				<tr>
					<th scope="row">Quelle</th>
					<td>
						<?php
						foreach ( array(
							'url'    => 'Bild-URL der Kamera abrufen',
							'folder' => 'Bilder aus einem Ordner importieren (FTP-Upload)',
							'both'   => 'Beides',
						) as $k => $label ) :
							?>
							<label style="margin-right:14px"><input type="radio" name="<?php echo esc_attr( $f ); ?>[source_mode]" value="<?php echo esc_attr( $k ); ?>" <?php checked( $c['source_mode'], $k ); ?>> <?php echo esc_html( $label ); ?></label>
						<?php endforeach; ?>
					</td>
				</tr>
				<tr>
					<th scope="row"><label for="<?php echo esc_attr( $uid ); ?>-url">Bild-URL</label></th>
					<td>
						<input type="url" id="<?php echo esc_attr( $uid ); ?>-url" class="large-text code" name="<?php echo esc_attr( $f ); ?>[source_url]" value="<?php echo esc_attr( $c['source_url'] ); ?>" placeholder="https://kamera.example.de/snapshot.jpg">
						<p style="margin-top:6px">
							<input type="text" autocomplete="off" name="<?php echo esc_attr( $f ); ?>[http_user]" value="<?php echo esc_attr( $c['http_user'] ); ?>" placeholder="Benutzer (optional)">
							<input type="password" autocomplete="new-password" name="<?php echo esc_attr( $f ); ?>[http_pass]" value="<?php echo esc_attr( $c['http_pass'] ); ?>" placeholder="Passwort (optional)">
							Timeout <input type="number" min="5" max="120" class="small-text" name="<?php echo esc_attr( $f ); ?>[timeout]" value="<?php echo esc_attr( $c['timeout'] ); ?>"> s
						</p>
					</td>
				</tr>
				<tr>
					<th scope="row"><label for="<?php echo esc_attr( $uid ); ?>-dir">Import-Ordner</label></th>
					<td>
						<input type="text" id="<?php echo esc_attr( $uid ); ?>-dir" class="large-text code" name="<?php echo esc_attr( $f ); ?>[import_dir]" value="<?php echo esc_attr( $c['import_dir'] ); ?>" placeholder="<?php echo esc_attr( wp_normalize_path( dirname( ABSPATH ) ) . '/webcam-ftp/' . ( $c['id'] ?: 'kamera2' ) ); ?>">
						<p class="description">Absoluter Serverpfad – pro Kamera ein eigener Ordner. Unterordner werden mit durchsucht.</p>
						<label><input type="checkbox" name="<?php echo esc_attr( $f ); ?>[delete_after_import]" value="1" <?php checked( $c['delete_after_import'] ); ?>> Dateien nach dem Import löschen</label>
					</td>
				</tr>
				<tr>
					<th scope="row">Zeitplan</th>
					<td>
						alle <input type="number" min="1" max="1440" class="small-text" name="<?php echo esc_attr( $f ); ?>[interval]" value="<?php echo esc_attr( $c['interval'] ); ?>"> Minuten,
						von <input type="time" name="<?php echo esc_attr( $f ); ?>[time_from]" value="<?php echo esc_attr( $c['time_from'] ); ?>">
						bis <input type="time" name="<?php echo esc_attr( $f ); ?>[time_to]" value="<?php echo esc_attr( $c['time_to'] ); ?>"> Uhr
						<p style="margin-top:6px"><label><input type="checkbox" name="<?php echo esc_attr( $f ); ?>[skip_duplicates]" value="1" <?php checked( $c['skip_duplicates'] ); ?>> Unveränderte Bilder nicht erneut speichern</label></p>
					</td>
				</tr>
				<tr>
					<th scope="row">Max. Breite</th>
					<td><input type="number" min="0" class="small-text" name="<?php echo esc_attr( $f ); ?>[max_width]" value="<?php echo esc_attr( $c['max_width'] ); ?>"> px <span class="description">(0 = Original unverändert speichern)</span></td>
				</tr>
				<tr>
					<th scope="row">Entfernen</th>
					<td>
						<label><input type="checkbox" class="wca-remove" name="<?php echo esc_attr( $f ); ?>[remove]" value="1"> Diese Kamera beim Speichern entfernen</label>
						<?php if ( ! $isnew ) : ?>
							<label style="margin-left:14px"><input type="checkbox" name="<?php echo esc_attr( $f ); ?>[remove_images]" value="1"> und alle ihre Bilder endgültig löschen</label>
						<?php endif; ?>
					</td>
				</tr>
			</table>
		</div>
		<?php
	}

	/* ---------------------------------------------------------------------
	 * Seite
	 * ------------------------------------------------------------------ */

	public static function page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$o      = WCA_Plugin::options();
		$name   = WCA_Plugin::OPTION;
		$next   = wp_next_scheduled( WCA_Plugin::CRON_CAPTURE );
		$log    = get_option( 'wca_log', array() );
		$notice = get_transient( 'wca_notice_' . get_current_user_id() );
		if ( $notice ) {
			delete_transient( 'wca_notice_' . get_current_user_id() );
		}
		$trigger = add_query_arg( 'key', $o['trigger_key'], rest_url( WCA_REST::NS . '/trigger' ) );
		$editor  = wp_image_editor_supports( array( 'mime_type' => 'image/jpeg' ) );
		?>
		<div class="wrap">
			<h1>Webcam Archiv</h1>
			<?php settings_errors( WCA_Plugin::OPTION ); ?>

			<?php if ( $notice ) : ?>
				<div class="notice <?php echo false !== strpos( $notice, 'Fehler' ) ? 'notice-error' : 'notice-success'; ?> is-dismissible"><p><?php echo esc_html( $notice ); ?></p></div>
			<?php endif; ?>
			<?php if ( ! $editor ) : ?>
				<div class="notice notice-warning"><p>Auf dem Server ist weder GD noch Imagick verfügbar – Vorschaubilder können nicht erzeugt werden.</p></div>
			<?php endif; ?>
			<?php if ( defined( 'DISABLE_WP_CRON' ) && DISABLE_WP_CRON ) : ?>
				<div class="notice notice-info"><p><code>DISABLE_WP_CRON</code> ist aktiv. Richte einen Server-Cronjob für die Trigger-URL unten ein.</p></div>
			<?php endif; ?>

			<div style="display:flex;gap:24px;flex-wrap:wrap;align-items:flex-start">
			<div style="flex:1 1 640px;min-width:320px">
			<form method="post" action="options.php" id="wca-form">
				<?php settings_fields( 'wca_settings' ); ?>

				<h2 class="title">Kameras</h2>
				<div id="wca-cameras">
					<?php
					$i = 0;
					foreach ( $o['cameras'] as $cam ) {
						self::camera_fields( $i++, $cam );
					}
					?>
				</div>
				<p><button type="button" class="button" id="wca-add"><span class="dashicons dashicons-plus-alt2" style="vertical-align:text-bottom"></span> Weitere Kamera hinzufügen</button></p>

				<template id="wca-camera-template">
					<?php self::camera_fields( '__IDX__', array_merge( WCA_Plugin::camera_defaults(), array( 'name' => '' ) ) ); ?>
				</template>

				<h2 class="title">Allgemein (alle Kameras)</h2>
				<table class="form-table" role="presentation">
					<tr>
						<th scope="row"><label for="wca-tw">Vorschaubild-Breite</label></th>
						<td><input type="number" id="wca-tw" min="80" max="1000" class="small-text" name="<?php echo esc_attr( $name ); ?>[thumb_width]" value="<?php echo esc_attr( $o['thumb_width'] ); ?>"> px</td>
					</tr>
					<tr>
						<th scope="row"><label for="wca-q">JPEG-Qualität</label></th>
						<td><input type="number" id="wca-q" min="30" max="100" class="small-text" name="<?php echo esc_attr( $name ); ?>[jpeg_quality]" value="<?php echo esc_attr( $o['jpeg_quality'] ); ?>"> <span class="description">(beim Verkleinern)</span></td>
					</tr>
					<tr>
						<th scope="row"><label for="wca-ret">Aufbewahrung</label></th>
						<td><input type="number" id="wca-ret" min="0" class="small-text" name="<?php echo esc_attr( $name ); ?>[retention_days]" value="<?php echo esc_attr( $o['retention_days'] ); ?>"> Tage <span class="description">(0 = unbegrenzt)</span></td>
					</tr>
					<tr>
						<th scope="row">Wochenbeginn</th>
						<td>
							<select name="<?php echo esc_attr( $name ); ?>[week_start]">
								<option value="1" <?php selected( $o['week_start'], 1 ); ?>>Montag</option>
								<option value="0" <?php selected( $o['week_start'], 0 ); ?>>Sonntag</option>
							</select>
						</td>
					</tr>
					<tr>
						<th scope="row">Zugriff</th>
						<td><label><input type="checkbox" name="<?php echo esc_attr( $name ); ?>[require_login]" value="1" <?php checked( $o['require_login'] ); ?>> Archiv nur für angemeldete Benutzer anzeigen</label></td>
					</tr>
					<tr>
						<th scope="row">Trigger-URL</th>
						<td>
							<input type="text" readonly class="large-text code" value="<?php echo esc_attr( $trigger ); ?>" onclick="this.select()">
							<p class="description">Für zuverlässige Aufnahmen diese URL jede Minute per Server-Cronjob aufrufen – jede Kamera wird dann in ihrem eigenen Intervall abgerufen:<br><code>* * * * * curl -s "<?php echo esc_html( $trigger ); ?>" &gt;/dev/null</code></p>
							<label><input type="checkbox" name="<?php echo esc_attr( $name ); ?>[regen_key]" value="1"> Neuen Schlüssel erzeugen</label>
						</td>
					</tr>
				</table>

				<?php submit_button( 'Einstellungen speichern' ); ?>
			</form>
			</div>

			<div style="flex:0 1 360px;min-width:300px">
				<?php
				foreach ( $o['cameras'] as $id => $cam ) :
					$stats  = WCA_Archiver::stats( $id );
					$latest = WCA_Archiver::latest( $id );
					$state  = WCA_Plugin::state( $id );
					?>
					<div class="card" style="max-width:none;margin-top:20px">
						<h2 class="title" style="margin-bottom:8px"><?php echo esc_html( $cam['name'] ); ?> <code style="font-size:12px;font-weight:normal"><?php echo esc_html( $id ); ?></code></h2>
						<?php if ( $latest ) : ?>
							<p><img src="<?php echo esc_url( $latest['thumb'] ); ?>" alt="" style="max-width:100%;height:auto;border-radius:4px"></p>
						<?php endif; ?>
						<table class="widefat striped" style="border:0">
							<tr><td>Bilder</td><td><strong><?php echo esc_html( number_format_i18n( $stats ? (int) $stats->cnt : 0 ) ); ?></strong> (<?php echo esc_html( size_format( $stats ? (int) $stats->bytes : 0, 1 ) ?: '0 B' ); ?>)</td></tr>
							<tr><td>Zeitraum</td><td><?php echo esc_html( $stats && $stats->first ? mysql2date( 'd.m.Y', $stats->first ) . ' – ' . mysql2date( 'd.m.Y H:i', $stats->last ) : '–' ); ?></td></tr>
							<tr><td>Letzter Abruf</td><td><?php echo esc_html( ! empty( $state['last_run'] ) ? mysql2date( 'd.m.Y H:i', $state['last_run'] ) : '–' ); ?></td></tr>
							<tr><td>Intervall</td><td>alle <?php echo (int) $cam['interval']; ?> Min., <?php echo esc_html( $cam['time_from'] . '–' . $cam['time_to'] ); ?> Uhr</td></tr>
						</table>
						<p style="margin-top:12px">
							<?php
							if ( in_array( $cam['source_mode'], array( 'url', 'both' ), true ) ) {
								self::action_button( 'capture', 'Jetzt Bild abrufen', $id, 'button button-primary' );
							}
							if ( in_array( $cam['source_mode'], array( 'folder', 'both' ), true ) ) {
								self::action_button( 'import', 'Ordner importieren', $id );
							}
							?>
						</p>
					</div>
				<?php endforeach; ?>

				<div class="card" style="max-width:none">
					<h2 class="title">Wartung</h2>
					<p>Nächster Cron-Lauf: <?php echo esc_html( $next ? wp_date( 'd.m.Y H:i', $next ) : 'nicht geplant' ); ?></p>
					<?php self::action_button( 'cleanup', 'Alte Bilder bereinigen' ); ?>
					<h3>Tag löschen</h3>
					<?php
					$opts = '';
					foreach ( $o['cameras'] as $id => $cam ) {
						$opts .= '<option value="' . esc_attr( $id ) . '">' . esc_html( $cam['name'] ) . '</option>';
					}
					// Kamera-Auswahl ersetzt hier das versteckte cam-Feld.
					self::action_button( 'delete_day', 'Löschen', '', 'button button-link-delete', '<select name="cam">' . $opts . '</select> <input type="date" name="date" required> ' );
					?>
				</div>

				<div class="card" style="max-width:none">
					<h2 class="title">Shortcodes</h2>
					<p><code>[webcam_archiv]</code><br>Kalender mit Umschalter zwischen allen Kameras.</p>
					<p><code>[webcam_archiv kamera="cam2"]</code><br>Nur eine Kamera. Mehrere: <code>kamera="cam1,cam3"</code>. Weitere Optionen: <code>datum="2026-11-09"</code>, <code>tempo="6"</code></p>
					<p><code>[webcam_aktuell kamera="cam2" refresh="60" archiv="/webcam-archiv/"]</code><br>Neuestes Bild einer Kamera, aktualisiert sich automatisch.</p>
				</div>
			</div>
			</div>

			<h2>Protokoll</h2>
			<?php if ( $log ) : ?>
				<table class="widefat striped" style="max-width:1000px">
					<thead><tr><th style="width:150px">Zeit</th><th style="width:60px">Status</th><th>Meldung</th></tr></thead>
					<tbody>
					<?php
					$labels = array(
						'ok'    => '✅',
						'info'  => 'ℹ️',
						'error' => '❌',
					);
					foreach ( $log as $e ) :
						?>
						<tr>
							<td><?php echo esc_html( mysql2date( 'd.m.Y H:i:s', $e['time'] ) ); ?></td>
							<td><?php echo esc_html( $labels[ $e['level'] ] ?? $e['level'] ); ?></td>
							<td><?php echo esc_html( $e['msg'] ); ?></td>
						</tr>
					<?php endforeach; ?>
					</tbody>
				</table>
				<p><?php self::action_button( 'clear_log', 'Protokoll leeren', '', 'button button-small' ); ?></p>
			<?php else : ?>
				<p>Noch keine Einträge.</p>
			<?php endif; ?>
		</div>

		<script>
		(function () {
			var list = document.getElementById('wca-cameras');
			var tpl = document.getElementById('wca-camera-template');
			document.getElementById('wca-add').addEventListener('click', function () {
				var idx = 'n' + Date.now();
				var wrap = document.createElement('div');
				wrap.innerHTML = tpl.innerHTML.split('__IDX__').join(idx);
				var box = wrap.firstElementChild;
				list.appendChild(box);
				box.querySelector('input[type=text]').focus();
			});
			list.addEventListener('change', function (e) {
				if (e.target.classList.contains('wca-remove')) {
					e.target.closest('.wca-camera').style.opacity = e.target.checked ? '.45' : '';
				}
			});
		})();
		</script>
		<?php
	}
}
