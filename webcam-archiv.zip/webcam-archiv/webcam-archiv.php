<?php
/**
 * Plugin Name:       Webcam Archiv
 * Description:       Archiviert Webcam-Bilder automatisch (per Bild-URL oder FTP-Upload-Ordner, beliebig viele Kameras) und macht sie über einen Kalender mit Tagesansicht und Zeitraffer wieder abrufbar. Shortcodes: [webcam_archiv] und [webcam_aktuell].
 * Version:           1.1.0
 * Requires at least: 5.8
 * Requires PHP:      7.4
 * Author:            Webcam Archiv
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       webcam-archiv
 */

defined( 'ABSPATH' ) || exit;

define( 'WCA_VERSION', '1.1.0' );
define( 'WCA_FILE', __FILE__ );
define( 'WCA_DIR', plugin_dir_path( __FILE__ ) );
define( 'WCA_URL', plugin_dir_url( __FILE__ ) );

require_once WCA_DIR . 'includes/class-wca-plugin.php';
require_once WCA_DIR . 'includes/class-wca-archiver.php';
require_once WCA_DIR . 'includes/class-wca-rest.php';
require_once WCA_DIR . 'includes/class-wca-frontend.php';
require_once WCA_DIR . 'includes/class-wca-admin.php';

register_activation_hook( __FILE__, array( 'WCA_Plugin', 'activate' ) );
register_deactivation_hook( __FILE__, array( 'WCA_Plugin', 'deactivate' ) );

add_action( 'plugins_loaded', array( 'WCA_Plugin', 'init' ) );
