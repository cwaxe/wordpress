<?php
/**
 * Hauptvorlage (Blog, Archive, Suche)
 *
 * @package Dunkel_Schlicht
 */

get_header();

if ( is_archive() ) :
	the_archive_title( '<h1 class="page-title">', '</h1>' );
elseif ( is_search() ) :
	/* translators: %s: Suchbegriff */
	echo '<h1 class="page-title">' . sprintf( esc_html__( 'Suche: %s', 'dunkel-schlicht' ), esc_html( get_search_query() ) ) . '</h1>';
endif;

if ( have_posts() ) :
	while ( have_posts() ) :
		the_post();
		?>
		<article id="post-<?php the_ID(); ?>" <?php post_class( 'entry' ); ?>>
			<?php if ( has_post_thumbnail() ) : ?>
				<a class="entry-thumbnail" href="<?php the_permalink(); ?>" tabindex="-1" aria-hidden="true"><?php the_post_thumbnail( 'large' ); ?></a>
			<?php endif; ?>

			<?php the_title( '<h2 class="entry-title"><a href="' . esc_url( get_permalink() ) . '">', '</a></h2>' ); ?>

			<?php if ( 'post' === get_post_type() ) : ?>
				<div class="entry-meta"><time datetime="<?php echo esc_attr( get_the_date( 'c' ) ); ?>"><?php echo esc_html( get_the_date() ); ?></time></div>
			<?php endif; ?>

			<div class="entry-content"><?php the_excerpt(); ?></div>
			<a class="read-more" href="<?php the_permalink(); ?>"><?php esc_html_e( 'Weiterlesen →', 'dunkel-schlicht' ); ?></a>
		</article>
		<?php
	endwhile;

	the_posts_pagination(
		array(
			'prev_text' => '←',
			'next_text' => '→',
		)
	);
else :
	?>
	<h1><?php esc_html_e( 'Nichts gefunden', 'dunkel-schlicht' ); ?></h1>
	<p><?php esc_html_e( 'Hier gibt es noch keine Inhalte.', 'dunkel-schlicht' ); ?></p>
	<?php get_search_form(); ?>
	<?php
endif;

get_footer();
